print("Let's Play Wordle!")
target = input("Target word: ")
f = open("guesses.txt", "r")
w = open("output.txt", "w")

def wstr(guess, word):
    wstr = ""
    loc = 0
    for ch in guess:
        if ch not in word:
            wstr += "."
        elif ch == word[loc]:
            wstr += "!"
        else:
            wstr += '?'
        loc += 1
    return wstr


print(target, file=w)
for line in f:
    print(f"{line.rstrip()} {wstr(line.rstrip(), target)}", file=w)

