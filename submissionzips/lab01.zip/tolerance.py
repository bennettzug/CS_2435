desiredWeight = int(input("Enter desired weight: "))
tolerance = int(input("Enter tolerance (as percentage): ")) * .01
minWeight = desiredWeight - tolerance * desiredWeight
maxWeight = desiredWeight + tolerance * desiredWeight
print("The range of accepted weight for the part is from {:.1f} to {:.1f}".format(minWeight, maxWeight))
