tempC = int(input("Enter the temperature in Celsius: "))
exactF = ((9 / 5) * tempC) + 32
approxF = (2 * tempC) + 30
print("The temperature in Fahrenheit is exactly {:.0f} degrees".format(exactF))
print("The temperature in Fahrenheit is approximately {:.0f} degrees".format(approxF))
