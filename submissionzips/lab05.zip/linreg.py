f = open("weather-data.txt")

print("This program computes the linear regression of weather data starting in 1900")

data = []
for line in f:
    parts = line.split(" ")
    year = int(parts[0]) - 1900
    temp = float(parts[1])
    info = (year, temp)
    data.append(info)

f.close()

xavg = 0
yavg = 0
for year, temp in data:
    xavg += year
    yavg += temp

xavg /= len(data)
yavg /= len(data)


numerator = 0
denominator = 0
for year, temp in data:
    numerator += (year - xavg) * (temp - yavg)
    denominator += (year - xavg) ** 2

m = numerator / denominator

c = yavg - m * xavg

print(f"m = {m:.6f}")
print(f"c = {c:.6f}")



