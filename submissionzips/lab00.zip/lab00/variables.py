x,y=5,4 
print(x,"+",y,"=",x+y)
print(x,"-",y,"=",x-y)
print(x,"*",y,"=",x*y)
print(x,"/",y,"=",x/y)
print(x,"%",y,"=",x%y)