print("intro to compsci \nis the class that i am in \nhere is my haiku ")
