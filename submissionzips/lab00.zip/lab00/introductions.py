print("Hello, my name is Bennett. I'm a freshman and majoring in graphic design. \
I'm in CS2435 because I'm doing a minor in computer science. Some of my hobbies are rock \
climbing, hanging out with friends, and reading.")