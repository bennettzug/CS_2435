def read_board(filename):
    with open(filename, 'r') as file:
        b = []
        for line in file:
            a = []
            for ch in line.rstrip():
                a.append(ch)
            b.append(a)
    return b


def write_output(board, filename):
    with open(filename, 'w') as file:
        for i in board:
            for j in i:
                file.write(str(j))
            file.write("\n")


def is_mine(board, r, c):
    try:
        if r < 0 or c < 0:
            return False
        if board[r][c] != '*':
            return False
        return True
    except IndexError:
        return False


def mine_neighbors(board, r, c):
    mines = 0
    if is_mine(board, r, c):
        mines = 9
    else:
        if is_mine(board, r - 1, c - 1):
            mines += 1
        if is_mine(board, r, c - 1):
            mines += 1
        if is_mine(board, r + 1, c - 1):
            mines += 1
        if is_mine(board, r - 1, c):
            mines += 1
        if is_mine(board, r + 1, c):
            mines += 1
        if is_mine(board, r - 1, c + 1):
            mines += 1
        if is_mine(board, r, c + 1):
            mines += 1
        if is_mine(board, r + 1, c + 1):
            mines += 1
    return mines


def update_board(board):
    num_board = []
    for row, i in enumerate(board):
        row_board = []
        for column, j in enumerate(i):
            if mine_neighbors(board, row, column) == 0:
                row_board.append('.')
            elif mine_neighbors(board, row, column) == 9:
                row_board.append('*')
            else:
                row_board.append(mine_neighbors(board, row, column))
        num_board.append(row_board)
    return num_board


def main():
    board = read_board("mines.txt")
    num_board = update_board(board)
    write_output(num_board, 'output.txt')


if __name__ == '__main__':
    main()
