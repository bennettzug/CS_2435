def read_board(filename):
    with open(filename, 'r') as f:
        b = []
        for line in f:
            b.append(line.rstrip())
        f.close()
    return b


def loc(board, y, x):
    if -1 < y < 8 and -1 < x < 8:
        return board[y][x]
    else:
        return False


def pawn_tester(board, y, x):
    if loc(board, y + 1, x + 1) == 'P' or loc(board, y + 1, x - 1) == 'P':
        return True
    else:
        return False


def knight_tester(board, y, x):
    if loc(board, y + 1, x + 2) == 'N' or loc(board, y + 2, x + 1) == 'N' or \
            loc(board, y + 2, x - 1) == 'N' or loc(board, y + 1, x - 2) == 'N' or \
            loc(board, y - 1, x - 2) == 'N' or loc(board, y - 2, x - 1) == 'N' or \
            loc(board, y - 2, x + 1) == 'N' or loc(board, y - 1, x + 2) == 'N':
        return True
    else:
        return False


def king_tester(board, y, x):
    if loc(board, y - 1, x - 1) == 'K' or loc(board, y - 1, x) == 'K' or \
            loc(board, y - 1, x + 1) == 'K' or \
            loc(board, y, x - 1) == 'K' or loc(board, y, x + 1) == 'K' or \
            loc(board, y + 1, x - 1) == 'K' or loc(board, y + 1, x) == 'K' or \
            loc(board, y + 1, x + 1) == 'K':
        return True
    else:
        return False


def projecting_piece_tester(board, y, x, y_activator, x_activator, piece):
    adder = 1

    while loc(board, y + (y_activator * adder), x + (x_activator * adder)) == '.':
        adder += 1
    if loc(board, y + (y_activator * adder), x + (x_activator * adder)) == piece:
        return True

    return False


def rook_tester(board, y, x):
    if projecting_piece_tester(board, y, x, 0, 1, 'R'):
        return True
    elif projecting_piece_tester(board, y, x, 0, -1, 'R'):
        return True
    elif projecting_piece_tester(board, y, x, 1, 0, 'R'):
        return True
    elif projecting_piece_tester(board, y, x, -1, 0, 'R'):
        return True
    else:
        return False


def bishop_tester(board, y, x):
    if projecting_piece_tester(board, y, x, 1, 1, 'B'):
        return True
    elif projecting_piece_tester(board, y, x, 1, -1, 'B'):
        return True
    elif projecting_piece_tester(board, y, x, -1, 1, 'B'):
        return True
    elif projecting_piece_tester(board, y, x, -1, -1, 'B'):
        return True
    else:
        return False


def queen_tester(board, y, x):
    if projecting_piece_tester(board, y, x, 0, 1, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, 0, -1, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, 1, 0, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, -1, 0, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, 1, 1, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, 1, -1, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, -1, 1, 'Q'):
        return True
    elif projecting_piece_tester(board, y, x, -1, -1, 'Q'):
        return True
    else:
        return False


def king_finder(board):
    king_y = 0
    king_x = 0
    for i, elem in enumerate(board):
        if elem.find('k') != -1:
            king_x = elem.find('k')
            king_y = i
    return king_y, king_x


def bk_in_check(board):
    king_y, king_x = king_finder(board)
    if pawn_tester(board, king_y, king_x) or knight_tester(board, king_y, king_x) or \
            king_tester(board, king_y, king_x) or rook_tester(board, king_y, king_x) or \
            bishop_tester(board, king_y, king_x) or queen_tester(board, king_y, king_x):
        return True
    else:
        return False


def main():
    board = read_board('chess.txt')
    isisnot = '' if bk_in_check(board) else 'not '
    print(f'Black king is {isisnot}in check.')


if __name__ == '__main__':
    main()
