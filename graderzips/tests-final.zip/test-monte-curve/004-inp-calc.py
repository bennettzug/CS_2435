import math
def func(x):
	return 4*x**2 + 4*x + 4