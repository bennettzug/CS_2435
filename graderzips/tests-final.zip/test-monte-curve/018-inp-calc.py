import math
def func(x):
	return 3*x**2 + 0.5*x