import math
def func(x):
	return x**3 + x + 3*x**0.5 + math.log(x)