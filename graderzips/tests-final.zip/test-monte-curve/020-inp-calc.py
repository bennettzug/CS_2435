import math
def func(x):
	return x**2 + 0.5*math.log10(x)