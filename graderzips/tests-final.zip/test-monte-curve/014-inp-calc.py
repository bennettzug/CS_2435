import math
def func(x):
	return 2*math.log10(x) + 0.25