import math
def func(x):
	return 0.25*x**3 + x**2 + 0.5*math.log(x) + 3