import math
def func(x):
	return 3*x**3 + x**0.5 + math.log(x) + math.log10(x)