import math
def func(x):
	return x**2 + math.log(x)