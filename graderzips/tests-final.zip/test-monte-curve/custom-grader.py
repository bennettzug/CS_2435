def check_output(actual, expect, type='stdout'):
	ALLOWED_ERROR = 0.05
	aout, eout = actual.read(), expect.read()
	if aout == '': return False, "program did not print any output"

	alines = aout.splitlines()
	elines = eout.splitlines()
	if len(alines) != len(elines):
		return False, None

	for aout,eout in list(zip(alines, elines))[:-1]:
		if aout != eout: return False, None
	aout = alines[-1].strip()
	eout = elines[-1].strip()

	try:
		avalue, evalue = float(aout), float(eout)
	except ValueError as e:
		return False, 'expected last line of output to be a single float value, got "{:s}"'.format(aout)
	error = abs(avalue-evalue) / evalue
	feedback = [
		"expected a value within 5% (.05) margin of error of {e:.03f}, got {a:.03f}".format(e=evalue, a=avalue),
		"this is a margin of error of {err:.1f}%".format(err=error*100),
	]
	return error <= ALLOWED_ERROR or error <= 5, '\n'.join(feedback)


