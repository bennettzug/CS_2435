import math
def func(x):
	return 3*x**0.5 + math.log10(x)