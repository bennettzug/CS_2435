import math
def func(x):
	return 0.25*x**3 + 0.5*x + 2*math.log10(x) + 3