import math
def func(x):
	return 0.5*x**2 + 2*x**0.5 + math.log(x) + math.log10(x)