import math
def func(x):
	return x**3 + 3*x