import math
def func(x):
	return x + 0.25*math.log(x)