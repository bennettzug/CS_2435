import math
def func(x):
	return math.log10(x)