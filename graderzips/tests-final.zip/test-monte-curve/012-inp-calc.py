import math
def func(x):
	return 3*x**3 + 3*math.log(x)