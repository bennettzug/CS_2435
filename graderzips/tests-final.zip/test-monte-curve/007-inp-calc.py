import math
def func(x):
	return x**0.5 + 0.5*math.log10(x)