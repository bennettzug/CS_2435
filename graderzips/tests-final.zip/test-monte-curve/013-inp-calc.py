import math
def func(x):
	return x**3 + 0.5*x**2 + 3*math.log(x)