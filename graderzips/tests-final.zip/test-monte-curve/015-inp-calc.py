import math
def func(x):
	return 2*x**0.5