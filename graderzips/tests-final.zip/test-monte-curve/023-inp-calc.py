import math
def func(x):
	return 0.25*x + 0.25