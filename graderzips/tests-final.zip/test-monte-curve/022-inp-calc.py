import math
def func(x):
	return 3*x**2 + 3*math.log10(x) + 0.5