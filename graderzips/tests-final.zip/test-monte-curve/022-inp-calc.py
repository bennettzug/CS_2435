import math
def func(x):
	return x + x**0.5