import math
def func(x):
	return x**2 + 3