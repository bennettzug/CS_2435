import math
def func(x):
	return x**3 + 0.5*x**2 + x + x**0.5