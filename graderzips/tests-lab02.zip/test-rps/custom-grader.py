def grade(report, update):
	trials = 100
	states = [('rock', 'paper', 'scissors'), ('paper', 'scissors', 'rock'), ('scissors', 'rock', 'paper')]
	report.tests = trials * len(states)
	
	x = 0
	for move,loses,wins in states:
		outcomes = {
			"Human chose {:s}. Computer chose {:s}. Computer wins.".format(move, loses): 0,
			"Human chose {:s}. Computer chose {:s}. Human wins.".format(move, wins): 0,
			"Human chose {:s}. Computer chose {:s}. Tie.".format(move, move): 0,
		}
		for i in range(trials):
			import sys
			import subprocess
			proc = subprocess.run([sys.executable, report.source], timeout=1,
				text=True, input=(move + "\n"), capture_output=True)

			clean = proc.stdout.strip()
			for p in outcomes.keys():
				if clean.endswith(p):
					outcomes[p] += 1
					if outcomes[p] * 2 > trials:
						report.error = "Distribution of outcomes is excessively non-random."
						report.passed = 0
						update(report, report.tests)
						return
					report.passed += 1
					continue
			x += 1
			update(report, x)


