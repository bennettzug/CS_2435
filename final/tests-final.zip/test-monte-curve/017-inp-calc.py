import math

def func(x):
	return 2*x**2 + 2*x + 0.5*x**0.5
