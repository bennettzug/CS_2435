import math

def func(x):
	return x**2 + 0.25*x
