import math

def func(x):
	return 2*x**3 + 0.5*math.log(x) + 0.5*math.log10(x)
