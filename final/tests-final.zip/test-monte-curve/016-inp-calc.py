import math

def func(x):
	return 2
