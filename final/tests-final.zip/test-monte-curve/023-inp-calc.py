import math

def func(x):
	return x**2 + 0.5*x**0.5 + 2*math.log(x)
