import math

def func(x):
	return 0.5*x**3 + 0.25*math.log(x)
