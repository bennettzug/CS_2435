import math

def func(x):
	return x**2 - x + 1
