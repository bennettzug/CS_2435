import math

def func(x):
	return 0.25*x**2 + 3*x + x**0.5 + 2*math.log(x)
