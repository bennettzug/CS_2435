import math

def func(x):
	return 3*x**3 + 2*math.log10(x)
