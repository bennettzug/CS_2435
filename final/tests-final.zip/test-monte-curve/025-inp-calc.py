import math

def func(x):
	return 0.5*x**2 + 2*x
