import math

def func(x):
	return 3*x**3 + 0.5*x**0.5
