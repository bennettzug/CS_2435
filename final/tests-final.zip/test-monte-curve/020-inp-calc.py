import math

def func(x):
	return x**0.5 + 3
