import math

def func(x):
	return x
