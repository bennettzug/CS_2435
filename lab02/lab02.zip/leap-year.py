year = int(input("Enter a year: "))
leapYear = None
if year % 400 == 0:
    leapYear = True
elif year % 100 == 0:
    leapYear = False
elif year % 4 == 0:
    leapYear = True
else:
    leapYear = False
leapYearStr = ''
if not leapYear:
    leapYearStr = 'not '
print("The year {:d} is {:s}a leap year.".format(year, leapYearStr))
