def check_output(actual, expect, type='stdout'):
	ALLOWED_ERROR = 0.01
	avalue = float(actual.read())
	evalue = float(expect.read())
	error = abs(avalue-evalue)
	feedback = [
		"expected a value within 1% (0.01) margin of error of {e:.03f}, got {a:.03f}".format(e=evalue, a=avalue),
		"this is a margin of error of {err:.1f}%".format(err=error*100),
	]
	return error <= ALLOWED_ERROR, '\n'.join(feedback)


