def check_output(actual, expect, type='stdout'):
	ALLOWED_ERROR = 0.01
	aout, eout = actual.read(), expect.read()
	if aout == '': return "program did not print any output", None

	avalue, evalue = float(aout), float(eout)
	error = abs(avalue-evalue)
	feedback = [
		"expected a value within 1% (0.01) margin of error of {e:.03f}, got {a:.03f}".format(e=evalue, a=avalue),
		"this is a margin of error of {err:.1f}%".format(err=error*100),
	]
	return error <= ALLOWED_ERROR, '\n'.join(feedback)


